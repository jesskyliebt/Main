#Step 4 Add Logic
param (
    [Parameter(Mandatory=$True)][string[]]$Computername
)

#Loop through each computer in computername parameter, and perform actions in code block
foreach ($target in $Computername) {

    #Enter Code Block Here and change variable to match foreach condition
    get-service -ComputerName $Computername   |
    Where-Object -Property Status -eq 'Stopped'

}
