﻿#OS Description

#Disk Freespace on OS Drive 

#Amount of System Memory

#Last Reboot of System

#IP Address & DNS Name

#DNS Server of Target

#Write Output to Screen 


